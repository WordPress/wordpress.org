<?php
namespace WordPressdotorg\Plugin_Directory\API\Routes;

use WordPressdotorg\Plugin_Directory\Plugin_Directory;
use WordPressdotorg\Plugin_Directory\API\Base;
use WordPressdotorg\Plugin_Directory\Template;

/**
 * WordPress.org is many different systems operating with one anothers data.
 * This endpoint offers internal w.org services a way to update stat data from
 * these other systems from outside WordPress while triggering all WordPress actions
 * and filters.
 *
 * This API is not designed for public usage, an API to fetch these statistics will also be
 * made available.
 *
 * @package WordPressdotorg_Plugin_Directory
 */
class Internal_Stats extends Base {

	function __construct() {
		register_rest_route( 'plugins/v1', '/update-stats', array(
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'bulk_update_stats' ),
			'permission_callback' => array( $this, 'permission_check_internal_api_bearer' ),
		) );
	}

	/**
	 * Endpoint to update a whitelisted set of postmeta fields for a bunch of plugin slugs.
	 *
	 * Data is in the format of
	 * plugins: {
	 *    plugin-slug: {
	 *      active_installs: 1000
	 *    },
	 *    plugin-slug-2: {
	 *       active_instals: 1000000
	 *    }
	 * }
	 *
	 * @param \WP_REST_Request $request The Rest API Request.
	 * @return bool true
	 */
	function bulk_update_stats( $request ) {
		$data = $request['plugins'];

		foreach ( $data as $plugin_slug => $stats ) {
			$plugin = Plugin_Directory::get_plugin_post( $plugin_slug );
			if ( ! $plugin ) {
				continue;
			}

			foreach ( $stats as $stat_name => $value ) {
				if ( 'active_installs' == $stat_name ) {
					// Store an unsanitized private version of the active_installs stat for consistent ordering.
					update_post_meta( $plugin->ID, '_active_installs', wp_slash( $value ) );

					$value = Template::sanitize_active_installs( $value );
				} elseif ( 'usage' == $stat_name ) {
					$value = $this->sanitize_usage_numbers( $value, $plugin );
				} elseif ( 'support_threads' == $stat_name || 'support_threads_resolved' == $stat_name ) {
					$value = (int) $value;
				} else {
					continue; // Unknown key
				}

				update_post_meta( $plugin->ID, $stat_name, wp_slash( $value ) );
			}
		}

		return true;
	}

	/**
	 * Sanitizes the usage figures for a plugin.
	 *
	 * Versions higher than the latest branch will be excluded.
	 * Versions which have a usage below 5% will be combined into 'other'
	 * unless it's the latest branch, or if there's only one branch which is less than 5%.
	 *
	 * @param array    $usage  An array of the branch usage numbers.
	 * @param \WP_Post $plugin The plugin's WP_Post instance.
	 * @return array An array containing the percentages for the given plugin.
	 */
	protected function sanitize_usage_numbers( $usage, $plugin ) {
		$latest_version = get_post_meta( $plugin->ID, 'version', true ) ?: '0.0';
		$latest_branch  = implode( '.', array_slice( explode( '.', $latest_version ), 0, 2 ) );

		// Exclude any version strings higher than the latest plugin version (ie. 99.9)
		foreach ( $usage as $version => $count ) {
			if ( version_compare( $version, $latest_version, '>' ) || 0 === strlen( $version ) ) {
				unset( $usage[ $version ] );
			}
		}

		// The percentage at which we combine versions into an "other" group.
		// Note: The latest branch will NOT fold into this.
		$percent_cut_off = 5;

		// Calculate the percentage of each version branch
		$total  = array_sum( $usage );
		$others = array();
		foreach ( $usage as $version => $count ) {
			$percent = round( $count / $total * 100, 2 );

			if ( $percent < $percent_cut_off && $version != $latest_branch ) {
				$others[ $version ] = $count;
				unset( $usage[ $version ] );
				continue;
			}
			$usage[ $version ] = $percent;
		}

		// If there was only one version < $percent_cut_off then display it as-is
		if ( count( $others ) == 1 ) {
			$version           = array_keys( $others );
			$version           = array_shift( $version );
			$usage[ $version ] = round( $others[ $version ] / $total * 100, 2 );
			// Else we'll add an 'others' version.
		} elseif ( count( $others ) > 1 ) {
			$usage['other'] = round( array_sum( $others ) / $total * 100, 2 );
		}

		// Due to rounding issues, sometimes we'll end up with the total being .01 or .02 off 100
		// In these cases, we'll just alter the 'other' or final number slightly so everything adds up to 100.
		// This is ultimately needed for the stats graphs to display properly.
		if ( $usage && array_sum( $usage ) != 100.00 ) {
			$last_key = array_keys( $usage )[ count( $usage ) - 1 ];
			$usage[ $last_key ] -= array_sum( $usage ) - 100.00;
		}

		return $usage;
	}

}
